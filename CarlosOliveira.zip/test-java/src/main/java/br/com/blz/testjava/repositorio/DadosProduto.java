package br.com.blz.testjava.repositorio;

import br.com.blz.testjava.item.ItemProduto;

public class DadosProduto {
    ItemProduto item = new ItemProduto();

    public ItemProduto listar() {
        //GET
        return item;
    }

    public ItemProduto inserir() {
        //POST
        return item;
    }

    public ItemProduto deletar() {
        //DELETE
        return item;
    }

    public ItemProduto alterar() {
        //PUT
        return item;
    }


}
