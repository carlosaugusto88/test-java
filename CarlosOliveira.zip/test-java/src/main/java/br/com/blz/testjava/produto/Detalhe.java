package br.com.blz.testjava.produto;

public class Detalhe {
    private int quantidade;
    private String estado;
    private Enum tipo;
}

/*
"warehouses": [
    {
    "locality": "SP",
    "quantity": 12,
    "type": "ECOMMERCE"
    }
    ]

 */
